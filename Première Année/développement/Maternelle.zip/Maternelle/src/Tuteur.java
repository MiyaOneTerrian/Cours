import java.util.ArrayList;

public class Tuteur {
	private String nom, prenom, addresse;
	
	// Arraylist de mesEnfants
	private ArrayList<Enfant> mesEnfants;
	
	public Tuteur() {
		
	}
	
	public void saisir() {
		
	}
	
	public void afficher() {
		
	}
	
	public void ajouterEnfant() {
		
	}
	
	public void listerEnfant() {
		
	}
	
	public String toString() {
		
	}
	
	public String toXml() {
		
	}
	
	public void gerer() {
		// menu de  gestion des fonctions d'un tuteur
	}
}
