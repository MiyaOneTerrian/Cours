
public class Directeur {
	private String nom, prenom, dataEntree;
	
	public Directeur() {
		
	}
	
	public void saisir() {
		
	}
	
	public void afficher() {
		
	}
	
	public String toString() {
		
	}
	
	public String toXml() {
		
	}
	
	// getters and setters
}
