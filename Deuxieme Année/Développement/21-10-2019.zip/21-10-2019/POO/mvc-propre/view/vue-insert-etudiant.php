<form method='post'>
<table border=0>
  <tr>
    <td>Nom:</td>
    <td>
      <input type="text" name="nom">
    </td>
  </tr>
  <tr>
    <td>Prenom:</td>
    <td>
      <input type="text" name="prenom">
    </td>
  </tr>
  <tr>
    <td>Email:</td>
    <td>
      <input type="text" name="email">
    </td>
  </tr>
  <tr>
    <td>Addresse:</td>
    <td>
      <input type="text" name="addresse">
    </td>
  </tr>
  <tr>
    <td>
      <input type="reset" name="Annuler" value="Annuler">
    </td>
    <td>
      <input type="submit" name="Valider" value="Valider">
    </td>
  </tr>
</table>
</form>
